import 'package:flutter/material.dart';

// ignore: must_be_immutable
class RESULTPAGE extends StatelessWidget {
  double bmiValue = 0;
  RESULTPAGE({super.key, required this.bmiValue});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Center(
          child: Container(
            height: 150,
            width: 400,
            color: Colors.lightBlue,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  "THIS IS YOUR BMI",
                  style: TextStyle(fontSize: 25),
                ),
                Text(
                  "BMI: ${bmiValue.toString().substring(0, 5)}",
                  style: const TextStyle(fontSize: 25),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
