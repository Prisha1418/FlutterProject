import 'package:flutter/material.dart';

import 'package:bmi_calc/screens/bmiresult.dart';

class FirstPage extends StatefulWidget {
  const FirstPage({super.key});

  @override
  State<FirstPage> createState() => _FirstPageState();
}

calcBMI({double height = 0.0, double weight = 0.0}) {
  height = height / 100;
  double bmiValue =
      (weight / (height * height)); //weight in KG and height in meter
  return bmiValue;
}

class _FirstPageState extends State<FirstPage> {
  double sliderValue = 100.0;
  int age = 16;
  double weight = 40.0;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          title: const Text('BMI CALCULATOR'),
          centerTitle: true,
          backgroundColor: const Color.fromARGB(196, 0, 1, 3)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  color: const Color.fromARGB(255, 153, 171, 243),
                  width: MediaQuery.of(context).size.width * 0.4,
                  height: MediaQuery.of(context).size.height * 0.2,
                  child: const Column(
                    children: [
                      Icon(
                        Icons.male,
                        size: 100,
                        color: Colors.white,
                      ),
                      Text(
                        "Male",
                        style: TextStyle(color: Colors.white, fontSize: 30),
                      )
                    ],
                  ),
                ),
                Container(
                  color: const Color.fromARGB(255, 153, 171, 243),
                  width: MediaQuery.of(context).size.width * 0.4,
                  height: MediaQuery.of(context).size.height * 0.2,
                  child: const Column(
                    children: [
                      Icon(
                        Icons.female,
                        size: 100,
                        color: Colors.white,
                      ),
                      Text("Female",
                          style: TextStyle(color: Colors.white, fontSize: 30))
                    ],
                  ),
                )
              ],
            ),
          ),
          // SizedBox(
          //   height: MediaQuery.of(context).size.height*0.2,

          // ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Container(
              color: const Color.fromARGB(255, 245, 114, 114),
              width: MediaQuery.of(context).size.width * 0.87,
              height: MediaQuery.of(context).size.height * 0.25,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  const Text(
                    "Height",
                    style: TextStyle(color: Colors.white, fontSize: 25),
                  ),
                  Text(
                    sliderValue.toString().substring(0, 5),
                    style: const TextStyle(color: Colors.white, fontSize: 60),
                  ),
                  Slider(
                    min: 100.0,
                    max: 250.0,
                    value: sliderValue,
                    onChanged: (value) {
                      sliderValue = value;
                      setState(() {});
                    },
                  )
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  color: const Color.fromARGB(255, 153, 171, 243),
                  width: MediaQuery.of(context).size.width * 0.4,
                  height: MediaQuery.of(context).size.height * 0.2,
                  child: Column(
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(top: 7),
                        child: Text(
                          "Weight",
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(
                          weight.toStringAsFixed(2),
                          style: const TextStyle(
                              color: Colors.white, fontSize: 50),
                        ),
                      ),
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                                top: 3, left: 20, right: 8),
                            child: IconButton(
                                onPressed: () {
                                  weight--;
                                  setState(() {});
                                },
                                icon: const Icon(
                                  Icons.remove,
                                  color: Colors.white,
                                )),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                top: 3, left: 2, right: 7),
                            child: IconButton(
                                onPressed: () {
                                  weight++;
                                  setState(() {});
                                },
                                icon: const Icon(
                                  Icons.add,
                                  color: Colors.white,
                                )),
                          )
                        ],
                      )
                    ],
                  ),
                ),
                Container(
                  color: const Color.fromARGB(255, 153, 171, 243),
                  width: MediaQuery.of(context).size.width * 0.4,
                  height: MediaQuery.of(context).size.height * 0.2,
                  child: Column(
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(top: 7),
                        child: Text("Age",
                            style:
                                TextStyle(color: Colors.white, fontSize: 20)),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(
                          age.toStringAsFixed(0),
                          style: const TextStyle(
                              color: Colors.white, fontSize: 50),
                        ),
                      ),
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                                top: 3, left: 20, right: 8),
                            child: IconButton(
                                onPressed: () {
                                  age--;
                                  setState(() {});
                                },
                                icon: const Icon(
                                  Icons.remove,
                                  color: Colors.white,
                                )),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                top: 3, left: 2, right: 7),
                            child: IconButton(
                                onPressed: () {
                                  age++;
                                  setState(() {});
                                },
                                icon: const Icon(
                                  Icons.add,
                                  color: Colors.white,
                                )),
                          )
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
          ),

          SizedBox(
            // height: 20,
            height: MediaQuery.of(context).size.height * 0.02,
          ),
          GestureDetector(
            onTap: () {
              double finalBMI = calcBMI(height: sliderValue, weight: weight);
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => RESULTPAGE(
                            bmiValue: finalBMI,
                          )));
            },
            child: Padding(
              padding: const EdgeInsets.only(top: 20),
              child: Container(
                color: Colors.lightBlue,
                width: MediaQuery.of(context).size.width * 0.87,
                height: MediaQuery.of(context).size.height * 0.1,
                child: const Center(
                  child: Text(
                    "CALCULATE ",
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    ));
  }
}
