import 'package:flutter/material.dart';
import 'package:musicapp/screens/homeScreen.dart';
import 'package:musicapp/screens/loading_screen.dart';
import 'package:musicapp/screens/homePage.dart';
import 'package:musicapp/screens/profile.dart';
import 'package:musicapp/screens/alexa.dart';
import 'package:musicapp/screens/search.dart';

void main() {
  runApp(MaterialApp(
    //home: LoadingScreen(),
    theme: ThemeData.dark(),

    initialRoute: '/',
    routes: {
      '/': (context) => const LoadingScreen(),
      '/home': (context) => const HomePage(),
      '/home2': (context) => const Home(),
      '/profile': (context) => const PROFILE(),
      '/alexa': (context) => const ALEXAPAGE(),
      '/search': (context) => const SEARCH()
    },
  ));
}
